package mazegen;

import java.awt.*;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.*;

public class MazeGenerator extends JPanel{
    private final Color BackgroundColor = new Color(63, 68, 71);
    private final Color BorderColor = new Color(37, 40, 41);

    private JButton generateButton = new JButton("Generate Maze");

    private JButton pauseButton = new JButton("Pause");

    private JButton continueButton = new JButton("Continue");

    private JButton stepButton = new JButton("Step");

    private JRadioButton primsButton = new JRadioButton("Prim's");
    private JRadioButton kruskalsButton = new JRadioButton("Kruskal's");

    private static final Dimension buttonDim = new Dimension(150, 32);

    private static final int BorderWidth = 8;
    private static int cellScale = 10;
    private static int mazeHeight = 1000;
    private static int mazeWidth = 1000;

    private Maze maze;

    private State state = State.Idle;

    private Timer timer;

    private static JSlider animationSlider = new JSlider(0, 100);

    private static JCheckBox checkBox = new JCheckBox();
    
     private JComboBox cellChooser = new JComboBox();
     private int[] cellSizes = {2, 5, 10, 25, 50, 100};

    private int algorithm = 1;

    private enum State {
        Idle, Generating
    }

    public MazeGenerator() {
        setLayout(new FlowLayout());

        timer = new Timer(0, new TimerListener());
        timer.setInitialDelay(0);

        MouseListener listener = new MouseListener();

        generateButton.setSize(buttonDim);
        generateButton.addMouseListener(listener);
        add(generateButton);

        pauseButton.setSize(buttonDim);
        pauseButton.addMouseListener(listener);
        add(pauseButton);

        continueButton.setSize(buttonDim);
        continueButton.addMouseListener(listener);
        continueButton.setEnabled(false);
        add(continueButton);

        stepButton.setSize(buttonDim);
        stepButton.addMouseListener(listener);
        stepButton.setEnabled(false);
        add(stepButton);

        animationSlider.setInverted(true);
        animationSlider.setValue(timer.getDelay());
        add(animationSlider);

        primsButton.setSize(buttonDim);
        primsButton.addMouseListener(listener);
        add(primsButton);

        kruskalsButton.setSize(buttonDim);
        kruskalsButton.addMouseListener(listener);
        kruskalsButton.setSelected(true);
        add(kruskalsButton);

        add(checkBox);
        
        
        for(int i = 0; i < cellSizes.length; i++){
            cellChooser.addItem(cellSizes[i]);
        }
        cellChooser.setSelectedIndex(2);
        
        add(cellChooser);
    }

    private void createMaze() {
        cellScale = cellSizes[cellChooser.getSelectedIndex()];
        maze = new Maze(mazeWidth, mazeHeight, cellScale, algorithm);
        state = State.Generating;
    }

    public void buildMaze() {
        if (!checkBox.isSelected()) {
            if (algorithm == 0) {
                while (!maze.primsAlgorithmStep());
            } else {
                while (!maze.kruskalsAlgorithmStep());
            }
            repaint();
            setIdle();
        } else {
            if (algorithm == 0) {
                if (maze.primsAlgorithmStep()) {
                    setIdle();
                    timer.setDelay(animationSlider.getValue());
                }
            } else {
                if (maze.kruskalsAlgorithmStep()) {
                    setIdle();
                    timer.setDelay(animationSlider.getValue());
                }
            }
            repaint();
        }
    }

    private void setIdle() {
        timer.stop();
        state = State.Idle;
        primsButton.setEnabled(true);
        kruskalsButton.setEnabled(true);
    }

    public class MouseListener extends MouseAdapter {

        @Override
        public void mouseClicked(MouseEvent e) {
            if (e.getSource() == generateButton) {
                createMaze();
                pauseButton.setEnabled(true);
                timer.start();
            } else if (e.getSource() == pauseButton) {
                timer.stop();
                pauseButton.setEnabled(false);
                stepButton.setEnabled(true);
                continueButton.setEnabled(true);
            } else if (e.getSource() == continueButton) {
                timer.start();
                pauseButton.setEnabled(true);
                stepButton.setEnabled(false);
            } else if (e.getSource() == stepButton) {
                timer.stop();
                buildMaze();
            } else if (e.getSource() == primsButton && primsButton.isEnabled()) {
                algorithm = 0;
                kruskalsButton.setSelected(false);
            } else if (e.getSource() == kruskalsButton && kruskalsButton.isEnabled()) {
                algorithm = 1;
                primsButton.setSelected(false);
            }
        }

    }

    public class TimerListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            switch (state) {
                case Generating:
                    timer.setDelay(animationSlider.getValue());
                    if(primsButton.isSelected()){
                        kruskalsButton.setEnabled(false);
                    }else{
                        primsButton.setEnabled(false);
                    }
                    stepButton.setEnabled(false);
                    continueButton.setEnabled(false);
                    buildMaze();
                    break;
                default:
                    return;
            }
        }
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        g.setColor(BackgroundColor);
        g.fillRect(0, 0, getWidth(), getHeight());

        g.setColor(BorderColor);
        g.fillRect(0, 0, getWidth(), BorderWidth);
        g.fillRect(getWidth() - BorderWidth, 0, BorderWidth, getHeight());
        
        Graphics drawMaze = g.create();
        drawMaze.translate(50,50);
        if (maze != null) {
            maze.paint(drawMaze);
        }
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame();

        Dimension frameDim = new Dimension(1115, 1150);
        frame.setSize(frameDim);

        MazeGenerator generator = new MazeGenerator();
        frame.add(generator);

        frame.setTitle("Maze Generator");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setResizable(false);
        frame.setVisible(true);
    }

}
