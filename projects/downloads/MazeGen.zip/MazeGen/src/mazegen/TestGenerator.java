package mazegen;

import java.awt.Color;
import java.awt.geom.Ellipse2D;
import java.util.concurrent.TimeUnit;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartFrame;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.data.function.LineFunction2D;
import org.jfree.data.general.DatasetUtilities;
import org.jfree.data.statistics.Regression;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;

public class TestGenerator {
	
	public TestGenerator() {
		runTests();
	}
	
	public void runTests() {
		
		XYSeriesCollection result = new XYSeriesCollection();
                int cellSize = 10;
                int min = 50;
                int max = 2000;
                int increment = 50;
                String title = "Minimum Spanning Tree Algorithms for Random Maze Generation";
                
              XYSeries seriesP = new XYSeries("Prim's Algorithm");
              XYSeries seriesK = new XYSeries("Kruskal's Algorithm");
              
		for (int i = min; i <= max; i+= increment) {
			/**Maze mp = new Maze(i, i, cellSize, 0);
                        long startTimeP = System.nanoTime();
                        while (!mp.primsAlgorithmStep());
			long endTimeP = System.nanoTime();
                        long durationP = endTimeP - startTimeP;
			seriesP.add(i,  TimeUnit.MILLISECONDS.convert(durationP, TimeUnit.NANOSECONDS));**/
                        
                        Maze mk = new Maze(i, i, cellSize, 1);
                        long startTimeK = System.nanoTime();
                        while (!mk.kruskalsAlgorithmStep());
			long endTimeK = System.nanoTime();
                        long durationK = endTimeK - startTimeK;
			seriesK.add(i,  TimeUnit.MILLISECONDS.convert(durationK, TimeUnit.NANOSECONDS));		
                }
                
                //result.addSeries(seriesP);
                result.addSeries(seriesK);
                
		JFreeChart chart = ChartFactory.createScatterPlot(title, "Maze Size", "Time (ms)", result);
		ChartFrame frame = new ChartFrame(title, chart);

                
		frame.pack();
                frame.setSize(2000, 1500);
                frame.setResizable(false);
		frame.setVisible(true);
                
	}
        
        public static void main(String[] args){
            TestGenerator tests = new TestGenerator();
        }

}